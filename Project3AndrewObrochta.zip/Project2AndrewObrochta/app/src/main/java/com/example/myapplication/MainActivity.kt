package com.example.myapplication

import android.Manifest
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.telephony.SmsManager
import android.widget.Button
import android.widget.EditText
import android.widget.GridLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var dbHelper: UserDatabaseHelper
    private lateinit var editWeightDate: EditText
    private lateinit var editWeightInput: EditText
    private lateinit var buttonAddWeight: Button
    private lateinit var buttonDeleteLastRow: Button
    private lateinit var gridLayoutEntries: GridLayout
    private lateinit var buttonSetPhoneNumber: Button
    private lateinit var buttonSetGoal: Button

    private val SMS_PERMISSION_CODE = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        dbHelper = UserDatabaseHelper(this)

        editWeightDate = findViewById(R.id.editWeightDate)
        editWeightInput = findViewById(R.id.editWeightInput)
        buttonAddWeight = findViewById(R.id.buttonAddWeight)
        buttonDeleteLastRow = findViewById(R.id.buttonDeleteLastRow)
        gridLayoutEntries = findViewById(R.id.gridLayoutEntries)
        buttonSetPhoneNumber = findViewById(R.id.buttonSetPhoneNumber)
        buttonSetGoal = findViewById(R.id.buttonSetGoal)

        // Request SMS permission if not already granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.SEND_SMS), SMS_PERMISSION_CODE)
        }

        loadEntries()

        buttonAddWeight.setOnClickListener {
            addWeightEntry()
        }

        buttonDeleteLastRow.setOnClickListener {
            deleteLastEntry()
        }

        buttonSetPhoneNumber.setOnClickListener {
            val intent = Intent(this, SetPhoneActivity::class.java)
            startActivity(intent)
        }

        buttonSetGoal.setOnClickListener {
            val intent = Intent(this, SetGoalActivity::class.java)
            startActivity(intent)
        }
    }

    private fun addWeightEntry() {
        val date = editWeightDate.text.toString()
        val weightStr = editWeightInput.text.toString()
        val weight = weightStr.toDoubleOrNull()

        if (date.isEmpty() || weight == null) {
            Toast.makeText(this, "Please enter a valid date and weight.", Toast.LENGTH_SHORT).show()
            return
        }

        val db = dbHelper.writableDatabase
        val values = ContentValues().apply {
            put(UserDatabaseHelper.COLUMN_DATE, date)
            put(UserDatabaseHelper.COLUMN_WEIGHT, weight)
        }

        val rowsAffected = db.update(
            UserDatabaseHelper.TABLE_WEIGHT,
            values,
            "${UserDatabaseHelper.COLUMN_DATE} = ?",
            arrayOf(date)
        )

        if (rowsAffected == 0) {
            db.insert(UserDatabaseHelper.TABLE_WEIGHT, null, values)
        }

        editWeightDate.text.clear()
        editWeightInput.text.clear()
        loadEntries()
        sendNotification("Weight entry added: $date - $weight kg")
    }

    private fun deleteLastEntry() {
        val db = dbHelper.writableDatabase
        val cursor = db.rawQuery("SELECT * FROM ${UserDatabaseHelper.TABLE_WEIGHT} ORDER BY ${UserDatabaseHelper.COLUMN_DATE} DESC LIMIT 1", null)
        if (cursor.moveToFirst()) {
            val date = cursor.getString(cursor.getColumnIndex(UserDatabaseHelper.COLUMN_DATE))
            db.delete(UserDatabaseHelper.TABLE_WEIGHT, "${UserDatabaseHelper.COLUMN_DATE} = ?", arrayOf(date))
        }
        cursor.close()
        loadEntries()
    }

    private fun loadEntries() {
        val db = dbHelper.readableDatabase
        val cursor = db.rawQuery("SELECT * FROM ${UserDatabaseHelper.TABLE_WEIGHT} ORDER BY ${UserDatabaseHelper.COLUMN_DATE}", null)

        gridLayoutEntries.removeAllViews()

        // Add header row
        val headerRow = TextView(this)
        headerRow.text = "Date | Weight"
        headerRow.textSize = 18f
        headerRow.setPadding(16, 16, 16, 16)
        headerRow.setBackgroundColor(ContextCompat.getColor(this, android.R.color.darker_gray))
        gridLayoutEntries.addView(headerRow)

        // Add data rows
        while (cursor.moveToNext()) {
            val date = cursor.getString(cursor.getColumnIndex(UserDatabaseHelper.COLUMN_DATE))
            val weight = cursor.getDouble(cursor.getColumnIndex(UserDatabaseHelper.COLUMN_WEIGHT))

            val entryRow = TextView(this)
            entryRow.text = "$date | $weight kg"
            entryRow.setPadding(16, 16, 16, 16)
            gridLayoutEntries.addView(entryRow)
        }
        cursor.close()
    }

    private fun sendNotification(message: String) {
        val sharedPreferences = getSharedPreferences("app_prefs", MODE_PRIVATE)
        val phoneNumber = sharedPreferences.getString("phone_number", null)

        if (phoneNumber != null && ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            val smsManager = SmsManager.getDefault()
            smsManager.sendTextMessage(phoneNumber, null, message, null, null)
        } else {
            Toast.makeText(this, "SMS permission not granted or phone number not set.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == SMS_PERMISSION_CODE && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "SMS permission granted", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show()
        }
    }
}