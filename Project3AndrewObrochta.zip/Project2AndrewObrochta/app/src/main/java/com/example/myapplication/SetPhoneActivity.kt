package com.example.myapplication

import android.content.Context
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class SetPhoneActivity : AppCompatActivity() {

    private lateinit var editPhoneNumber: EditText
    private lateinit var buttonSavePhoneNumber: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_set_phone)

        // Initialize UI elements
        editPhoneNumber = findViewById(R.id.editPhoneNumber)
        buttonSavePhoneNumber = findViewById(R.id.buttonSavePhoneNumber)

        // Set up the click listener for the Save button
        buttonSavePhoneNumber.setOnClickListener {
            val phoneNumber = editPhoneNumber.text.toString()

            if (phoneNumber.isEmpty()) {
                Toast.makeText(this, "Please enter a phone number.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Save the phone number in SharedPreferences
            val sharedPreferences = getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
            val editor = sharedPreferences.edit()
            editor.putString("phone_number", phoneNumber)
            editor.apply()

            Toast.makeText(this, "Phone number saved.", Toast.LENGTH_SHORT).show()
            finish() // Close the activity and return to the previous screen
        }
    }
}