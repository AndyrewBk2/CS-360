package com.example.myapplication


import android.content.ContentValues
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {

    private lateinit var dbHelper: UserDatabaseHelper
    private lateinit var editUsername: EditText
    private lateinit var editPassword: EditText
    private lateinit var buttonLogin: Button
    private lateinit var buttonRegister: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        dbHelper = UserDatabaseHelper(this)

        editUsername = findViewById(R.id.editUsername)
        editPassword = findViewById(R.id.editPassword)
        buttonLogin = findViewById(R.id.buttonLogin)
        buttonRegister = findViewById(R.id.buttonRegister)

        buttonLogin.setOnClickListener {
            loginUser()
        }

        buttonRegister.setOnClickListener {
            registerUser()
        }
    }

    private fun loginUser() {
        val username = editUsername.text.toString()
        val password = editPassword.text.toString()

        val db = dbHelper.readableDatabase
        val cursor = db.rawQuery(
            "SELECT * FROM ${UserDatabaseHelper.TABLE_USERS} WHERE ${UserDatabaseHelper.COLUMN_USERNAME} = ? AND ${UserDatabaseHelper.COLUMN_PASSWORD} = ?",
            arrayOf(username, password)
        )

        if (cursor.moveToFirst()) {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
        } else {
            Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show()
        }
        cursor.close()
    }

    private fun registerUser() {
        val username = editUsername.text.toString()
        val password = editPassword.text.toString()

        val db = dbHelper.writableDatabase
        val values = ContentValues().apply {
            put(UserDatabaseHelper.COLUMN_USERNAME, username)
            put(UserDatabaseHelper.COLUMN_PASSWORD, password)
        }

        val result = db.insert(UserDatabaseHelper.TABLE_USERS, null, values)
        if (result != -1L) {
            Toast.makeText(this, "User registered successfully", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Registration failed", Toast.LENGTH_SHORT).show()
        }
    }
}