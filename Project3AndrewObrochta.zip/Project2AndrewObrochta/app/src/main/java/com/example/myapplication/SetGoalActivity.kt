package com.example.myapplication

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class SetGoalActivity : AppCompatActivity() {

    private lateinit var editTextGoal: EditText
    private lateinit var buttonSaveGoal: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_set_goal)

        editTextGoal = findViewById(R.id.editTextGoal)
        buttonSaveGoal = findViewById(R.id.buttonSaveGoal)

        buttonSaveGoal.setOnClickListener {
            val goal = editTextGoal.text.toString().toDoubleOrNull()
            if (goal != null) {
                saveGoal(goal)
                Toast.makeText(this, "Goal saved!", Toast.LENGTH_SHORT).show()
                finish() // Close the activity
            } else {
                Toast.makeText(this, "Please enter a valid number.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun saveGoal(goal: Double) {
        // Save the goal to shared preferences or database
        val sharedPreferences = getSharedPreferences("MyPreferences", MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.putFloat("weight_goal", goal.toFloat())
        editor.apply()
    }
}